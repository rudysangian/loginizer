import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'dart:html' as html;
import 'package:youtube_player_iframe/youtube_player_iframe.dart';
import 'pages/vessel_track_page.dart';

void main() {
  runApp(MyIPMWeb());
}

class MyIPMWeb extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Indonesian Port Logistics Advisor | IPM by Rudy Sangian',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        useMaterial3: true,
      ),
      debugShowCheckedModeBanner: false,
      initialRoute: '/',
      routes: {
        '/': (context) => HomePage(),
        '/about': (context) => AboutPage(),
        '/track': (context) => VesselTrackPage(),
      },
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String responseText = '';
  TextEditingController _controller = TextEditingController();
  bool showInput = false;

  Future<void> consultGPT(BuildContext context) async {
    final uri = Uri.parse('https://rudysangian.com/chat');
    try {
      final userInput = _controller.text.trim();
      if (userInput.isEmpty) return;

      final response = await http.post(
        uri,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          "messages": [
            {
              "role": "system",
              "content":
                  "You are a port logistics consultant. Reply in the same language as the user's question (English or Indonesian). Always keep the answer short.",
            },
            {"role": "user", "content": userInput},
          ],
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          responseText = data['content'];
        });
      } else {
        setState(() {
          responseText = '⚠️ GPT error: ${response.statusCode}';
        });
      }
    } catch (e) {
      setState(() {
        responseText = '⚠️ Exception: $e';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('IPM e-Consultant'),
        backgroundColor: Colors.indigo,
        foregroundColor: Colors.white,
      ),
      drawer: AppDrawer(),
      body: Stack(
        children: [
          Positioned.fill(
            child: Opacity(
              opacity: 0.2,
              child: Image.asset(
                'assets/images/background.jpg',
                fit: BoxFit.cover,
              ),
            ),
          ),
          Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircleAvatar(
                    radius: 60,
                    backgroundImage: AssetImage('assets/images/profil.png'),
                  ),
                  const SizedBox(height: 24),
                  Text(
                    'Indonesian Port Logistics e-Consultant',
                    style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                      color: Colors.indigo[900],
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'Understand the 83 integrated port logistics processes behind Indonesia’s maritime trade efficiency. Built from local expertise, ready for global adoption.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 18),
                  ),
                  const SizedBox(height: 24),
                  ElevatedButton(
                    onPressed: () {
                      setState(() {
                        showInput = true;
                      });
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.indigo,
                      padding: EdgeInsets.symmetric(
                        horizontal: 32,
                        vertical: 16,
                      ),
                    ),
                    child: const Text(
                      'Get Instant Answers on Port Logistics',
                      style: TextStyle(fontSize: 16, color: Colors.white),
                    ),
                  ),
                  if (showInput) ...[
                    const SizedBox(height: 24),
                    const Text('Please type your question:'),
                    const SizedBox(height: 8),
                    TextField(
                      controller: _controller,
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        hintText: 'e.g. What is IPM Coordination?',
                      ),
                    ),
                    const SizedBox(height: 12),
                    ElevatedButton(
                      onPressed: () => consultGPT(context),
                      child: const Text('Submit'),
                    ),
                    const SizedBox(height: 16),
                    Text(responseText, style: TextStyle(fontSize: 16)),
                  ],
                  const SizedBox(height: 40),
                  const Text(
                    '© 2025 Rudy Sangian — Designed in Indonesia | For Port Logistics Worldwide',
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class AboutPage extends StatefulWidget {
  @override
  State<AboutPage> createState() => _AboutPageState();
}

class _AboutPageState extends State<AboutPage> {
  late YoutubePlayerController _controller;

  @override
  void initState() {
    super.initState();
    _setupController();
  }

  void _setupController() {
    _controller = YoutubePlayerController.fromVideoId(
      videoId: 'oSBdA90FsrI',
      autoPlay: false,
      params: const YoutubePlayerParams(
        showFullscreenButton: true,
        showControls: true,
      ),
    );
  }

  @override
  void dispose() {
    _controller.close();
    super.dispose();
  }

  void navigateHome(BuildContext context) {
    Navigator.pop(context); // tutup drawer dulu
    Future.delayed(const Duration(milliseconds: 300), () {
      Navigator.pushReplacementNamed(context, '/');
    });
  }

  @override
  Widget build(BuildContext context) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_controller.metadata.title == null) {
        setState(() {
          _setupController(); // Reset jika metadata belum ada
        });
      }
    });

    return YoutubePlayerScaffold(
      controller: _controller,
      builder: (context, player) {
        return Scaffold(
          appBar: AppBar(
            title: const Text('About IPM Framework'),
            backgroundColor: Colors.indigo,
            foregroundColor: Colors.white,
          ),
          drawer: Drawer(
            child: ListView(
              children: [
                const DrawerHeader(
                  decoration: BoxDecoration(color: Colors.indigo),
                  child: Text(
                    'Menu',
                    style: TextStyle(color: Colors.white, fontSize: 24),
                  ),
                ),
                ListTile(
                  leading: const Icon(Icons.home),
                  title: const Text('Home'),
                  onTap: () => navigateHome(context),
                ),
                ListTile(
                  leading: const Icon(Icons.info),
                  title: const Text('About IPM'),
                  onTap: () {
                    Navigator.pop(context); // tetap di halaman About
                  },
                ),
              ],
            ),
          ),
          body: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'What is IPM?',
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 16),
                const Text(
                  'IPM stands for Integrated Port Model — a framework to coordinate 83 port logistics processes under the 3P: Regulator, Operator, and Community.',
                  style: TextStyle(fontSize: 16),
                ),
                const SizedBox(height: 32),
                const Text(
                  'Watch IPM in the 3P Logistics Coordination:',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 12),
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: player,
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class AppDrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          const DrawerHeader(
            decoration: BoxDecoration(color: Colors.indigo),
            child: Text(
              'Menu',
              style: TextStyle(color: Colors.white, fontSize: 24),
            ),
          ),
          ListTile(
            leading: Icon(Icons.home),
            title: const Text('Home'),
            onTap: () {
              Navigator.pushNamed(context, '/');
            },
          ),
          ListTile(
            leading: Icon(Icons.info),
            title: const Text('About IPM'),
            onTap: () {
              Navigator.pushNamed(context, '/about');
            },
          ),
          ListTile(
            leading: Icon(Icons.map),
            title: const Text('Check Vessel Location'),
            onTap: () {
              Navigator.pushNamed(context, '/Vessel Track');
            },
          ),
        ],
      ),
    );
  }
}
