
import 'package:flutter/material.dart';
import 'dart:html' as html;
import 'dart:ui' as ui;
import 'package:flutter/foundation.dart';

class VesselTrackPage extends StatelessWidget {
  VesselTrackPage({super.key}) {
    if (kIsWeb) {
      // ignore: undefined_prefixed_name
      ui.platformViewRegistry.registerViewFactory(
        'iframeElement',
        (int viewId) => html.IFrameElement()
          ..src = 'https://www.marinetraffic.com/en/ais/embed/zoom:10/centery:-6.2/centerx:108.5/maptype:1'
          ..style.border = 'none'
          ..width = '100%'
          ..height = '600',
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Check Your Vessel Location'),
        backgroundColor: Colors.indigo,
        foregroundColor: Colors.white,
      ),
      drawer: Drawer(
        child: ListView(
          children: const [
            DrawerHeader(
              decoration: BoxDecoration(color: Colors.indigo),
              child: Text('Menu', style: TextStyle(color: Colors.white, fontSize: 24)),
            ),
            ListTile(
              leading: Icon(Icons.home),
              title: Text('Home'),
            ),
          ],
        ),
      ),
      body: const Center(
        child: HtmlElementView(viewType: 'iframeElement'),
      ),
    );
  }
}
