package com.example.ipm_web

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
